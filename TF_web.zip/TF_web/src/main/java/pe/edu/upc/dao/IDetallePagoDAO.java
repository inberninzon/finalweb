package pe.edu.upc.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.upc.entity.DetallePago;

@Repository
public interface IDetallePagoDAO extends JpaRepository<DetallePago, Integer> {

	List<DetallePago> findBydescripcion(String descripcion);

	@Query("from DetallePago d where d.cliente.nombreCliente like %:nombreCliente%")
	List<DetallePago> findBynombreCliente(@Param("nombreCliente") String nombreCliente);
}
