package pe.edu.upc.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entity.DetallePago;
import pe.edu.upc.service.IClienteSERVICE;
import pe.edu.upc.service.IDetallePagoSERVICE;
import pe.edu.upc.service.IMembresiaSERVICE;

@Controller
@RequestMapping("/detallepago")
public class DetallePagoController {
	@Autowired
	private IDetallePagoSERVICE dService;

	@Autowired
	private IClienteSERVICE cService;

	@Autowired
	private IMembresiaSERVICE mService;

	@RequestMapping("/")
	public String irDetalle(Map<String, Object> model) {
		model.put("listaDetalles", dService.listar());
		return "listDetallePago";
	}

	@RequestMapping("/irRegistrar")
	public String irRegistrar(Model model) {
		model.addAttribute("detallepago", new DetallePago());
		model.addAttribute("listaClientes", cService.listar());
		model.addAttribute("listaMembresias", mService.listar());

		return "detallepago";
	}

	@RequestMapping("/registrar")
	public String registrar(Model model, @ModelAttribute @Valid DetallePago detallepago, BindingResult binRes)
			throws ParseException {
		if (binRes.hasErrors()) {
			return "detallepago";
		} else {

			if (detallepago.getIdDetalle() > 0) {
				dService.modificar(detallepago);
			} else {
				dService.insertar(detallepago);
			}
			model.addAttribute("listaClientes", cService.listar());
			model.addAttribute("listaMembresias", mService.listar());
			return "redirect:/detallepago/listar";

		}
	}

	@RequestMapping("/modificar")
	public String modificar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		DetallePago dep = dService.listarId(id);

		model.put("listaClientes", cService.listar());
		model.put("listaMembresias", mService.listar());
		model.put("detallepago", dep);

		return "detallepago";
	}

	@RequestMapping("/eliminar")
	public String eliminar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				dService.eliminar(id);
				model.put("listaDetalles", dService.listar());
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "listDetallePago";
	}

	@RequestMapping("/listar")
	public String listar(Map<String, Object> model) {

		model.put("listaDetalles", dService.listar());
		return "listDetallePago";
	}

	@RequestMapping("/listarId")
	public String listarId(Map<String, Object> model, @ModelAttribute DetallePago detallepago) {
		dService.listarId(detallepago.getIdDetalle());
		return "listDetallePago";
	}

	@RequestMapping("/buscar")
	public String buscar(Map<String, Object> model, @ModelAttribute DetallePago detallepago) throws ParseException {
		List<DetallePago> listaDetalles;
		if (StringUtils.isAllLowerCase(detallepago.getDescripcion())) {
			listaDetalles = dService.findBydescripcion(detallepago.getDescripcion());

		} else {
			listaDetalles = dService.findBynombreCliente(detallepago.getDescripcion());

		}

		if (listaDetalles.isEmpty()) {

			model.put("mensaje", "No se encontró");
		}
		model.put("listaDetalles", listaDetalles);
		return "buscarDetalle";
	}

	@RequestMapping("/irBuscar")
	public String irBuscar(Model model) {
		model.addAttribute("detallepago", new DetallePago());
		return "buscarDetalle";
	}

}
