package pe.edu.upc.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entity.Asistencia;
import pe.edu.upc.service.IAsistenciaSERVICE;
import pe.edu.upc.service.IClienteSERVICE;
import pe.edu.upc.service.INivelSERVICE;

@Controller
@RequestMapping("/asistencia")
public class AsistenciaController {

	@Autowired
	private IClienteSERVICE cService;

	@Autowired
	private INivelSERVICE nService;

	@Autowired
	private IAsistenciaSERVICE aService;

	@RequestMapping("/")
	public String irAsistencia(Map<String, Object> model) {
		model.put("listaAsistencias", aService.listar());
		return "listAsistencia";
	}

	@RequestMapping("/irRegistrar")
	public String irRegistrar(Model model) {
		model.addAttribute("asistencia", new Asistencia());
		model.addAttribute("listaClientes", cService.listar());
		model.addAttribute("listaNiveles", nService.listar());

		return "asistencia";
	}

	@RequestMapping("/registrar")
	public String registrar(Model model, @ModelAttribute @Valid Asistencia asistencia, BindingResult binRes)
			throws ParseException {
		if (binRes.hasErrors()) {
			return "asistencia";
		} else {

			if (asistencia.getIdAsistencia() > 0) {
				aService.modificar(asistencia);
			} else {
				aService.insertar(asistencia);
			}
			model.addAttribute("listaClientes", cService.listar());
			model.addAttribute("listaNiveles", nService.listar());
			return "redirect:/asistencia/listar";

		}
	}

	@RequestMapping("/modificar")
	public String modificar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		Asistencia asi = aService.listarId(id);
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		asi.setFechaString(sdf.format(asi.getFechaClase()));
		model.put("listaClientes", cService.listar());
		model.put("listaNiveles", nService.listar());
		model.put("asistencia", asi);

		return "asistencia";
	}

	@RequestMapping("/eliminar")
	public String eliminar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				aService.eliminar(id);
				model.put("listaAsistencias", aService.listar());
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "listAsistencia";
	}

	@RequestMapping("/listar")
	public String listar(Map<String, Object> model) {

		model.put("listaAsistencias", aService.listar());
		return "listAsistencia";
	}

	@RequestMapping("/listarId")
	public String listarId(Map<String, Object> model, @ModelAttribute Asistencia asistencia) {
		aService.listarId(asistencia.getIdAsistencia());
		return "listAsistencia";
	}

	@RequestMapping("/buscar")
	public String buscar(Map<String, Object> model, @ModelAttribute Asistencia asistencia) throws ParseException {
		List<Asistencia> listaAsistencias;
		if (StringUtils.isAllLowerCase(asistencia.getTipoCliente())) {
			listaAsistencias = aService.findBytipoCliente(asistencia.getTipoCliente());

		} else {

			listaAsistencias = aService.findBynombreCliente(asistencia.getTipoCliente());

		}

		if (listaAsistencias.isEmpty()) {

			model.put("mensaje", "No se encontró");
		}
		model.put("listaAsistencias", listaAsistencias);
		return "buscarAsistencia";
	}

	@RequestMapping("/irBuscar")
	public String irBuscar(Model model) {
		model.addAttribute("asistencia", new Asistencia());
		return "buscarAsistencia";
	}
}
