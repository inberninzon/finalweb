package pe.edu.upc.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "cliente")
public class Cliente implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idCliente;

	@NotEmpty(message = "No puede estar vacío")
	@NotBlank(message = "No puede estar en blanco")
	@Column(name = "nombreCliente", length = 60, nullable = false)
	private String nombreCliente;

	@Size(min = 8, max = 8, message = "Debe tener 8 cifras")
	@Range(min = 0, max = 99999999, message = "Debe ser numero")
	@Column(name = "dniCliente", length = 8, nullable = false)
	private String dniCliente;

	@NotNull
	@Past(message = "La fecha debe estar en el pasado")
	@Temporal(TemporalType.DATE)
	@Column(name = "birthDateCliente")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date birthDateCliente;

	@NotEmpty(message = "No puede estar vacío")
	@NotBlank(message = "No puede estar en blanco")
	@Email
	@Column(name = "emailCliente", length = 60, nullable = false)
	private String emailCliente;

	private String fechaString;

	public Cliente() {
		super();
	}

	public Cliente(int idCliente, String nombreCliente, String dniCliente, Date birthDateCliente, String emailCliente,
			String fechaString) {
		super();
		this.idCliente = idCliente;
		this.nombreCliente = nombreCliente;
		this.dniCliente = dniCliente;
		this.birthDateCliente = birthDateCliente;
		this.emailCliente = emailCliente;
		this.fechaString = fechaString;
	}

	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public String getNombreCliente() {
		return nombreCliente;
	}

	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}

	public String getDniCliente() {
		return dniCliente;
	}

	public void setDniCliente(String dniCliente) {
		this.dniCliente = dniCliente;
	}

	public Date getBirthDateCliente() {
		return birthDateCliente;
	}

	public void setBirthDateCliente(Date birthDateCliente) {
		this.birthDateCliente = birthDateCliente;
	}

	public String getEmailCliente() {
		return emailCliente;
	}

	public void setEmailCliente(String emailCliente) {
		this.emailCliente = emailCliente;
	}

	public String getFechaString() {
		return fechaString;
	}

	public void setFechaString(String fechaString) {
		this.fechaString = fechaString;
	}

}
