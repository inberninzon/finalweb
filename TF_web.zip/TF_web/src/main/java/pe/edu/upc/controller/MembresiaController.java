package pe.edu.upc.controller;

import java.text.ParseException;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entity.Membresia;
import pe.edu.upc.service.IMembresiaSERVICE;

@Controller
@RequestMapping("/membresia")
public class MembresiaController {

	@Autowired
	private IMembresiaSERVICE membresiaService;

	@RequestMapping("/")
	public String irMembresia(Map<String, Object> model) {
		model.put("listaMembresias", membresiaService.listar());
		return "listMembresia";
	}

	@RequestMapping("/irRegistrar")
	public String irRegistrar(Model model) {
		model.addAttribute("membresia", new Membresia());
		return "membresia";
	}

	@RequestMapping("/registrar")
	public String registrar(Map<String, Object> model, @ModelAttribute @Valid Membresia membresia, BindingResult binRes)
			throws ParseException {
		if (binRes.hasErrors()) {
			return "membresia";
		} else {
			if (membresia.getIdMembresia() > 0) {
				membresiaService.modificar(membresia);
			} else {
				membresiaService.insertar(membresia);
			}
			model.put("listaMembresias", membresiaService.listar());
			model.put("Mensaje", "Error!!");
			return "listMembresia";
		}
	}

	@RequestMapping("/modificar")
	public String modificar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		Membresia mem = membresiaService.listarId(id);
		model.put("membresia", mem);
		return "membresia";
	}

	@RequestMapping("/eliminar")
	public String eliminar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				membresiaService.eliminar(id);
				model.put("listaMembresias", membresiaService.listar());
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "listMembresia";
	}

	@RequestMapping("/listar")
	public String listar(Map<String, Object> model) {

		model.put("listaMembresias", membresiaService.listar());
		return "listMembresia";
	}

	@RequestMapping("/listarId")
	public String listarId(Map<String, Object> model, @ModelAttribute Membresia membresia) {
		membresiaService.listarId(membresia.getIdMembresia());
		return "listMembresia";
	}
}
