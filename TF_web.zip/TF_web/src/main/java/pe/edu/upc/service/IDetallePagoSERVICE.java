package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entity.DetallePago;

public interface IDetallePagoSERVICE {

	void insertar(DetallePago detallepago);

	void modificar(DetallePago detallepago);

	void eliminar(int idDetallePago);

	DetallePago listarId(int idDetallePago);

	List<DetallePago> listar();

	List<DetallePago> findBydescripcion(String descripcion);

	List<DetallePago> findBynombreCliente(String nombreCliente);
}
