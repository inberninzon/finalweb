package pe.edu.upc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.dao.INivelDAO;
import pe.edu.upc.entity.Nivel;

@Service
public class NivelSERVICEImpl implements INivelSERVICE {

	@Autowired
	private INivelDAO nDAO;

	@Override
	public void insertar(Nivel nivel) {
		nDAO.save(nivel);

	}

	@Override
	public void modificar(Nivel nivel) {
		nDAO.save(nivel);

	}

	@Override
	public void eliminar(int idNivel) {
		nDAO.delete(idNivel);

	}

	@Override
	public Nivel listarId(int idNivel) {
		return nDAO.findOne(idNivel);
	}

	@Override
	public List<Nivel> listar() {
		return nDAO.findAll();
	}

}
