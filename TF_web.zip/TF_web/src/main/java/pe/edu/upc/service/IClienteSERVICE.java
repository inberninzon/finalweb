package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entity.Cliente;

public interface IClienteSERVICE {

	void insertar(Cliente cliente);

	void modificar(Cliente cliente);

	void eliminar(int idCliente);

	Cliente listarId(int idCliente);

	List<Cliente> listar();

	List<Cliente> findByDniCliente(String dni);

	List<Cliente> buscarNombre(String name);

}
