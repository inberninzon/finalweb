package pe.edu.upc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.dao.IDetallePagoDAO;
import pe.edu.upc.entity.DetallePago;

@Service
public class DetallePagoSERVICEImpl implements IDetallePagoSERVICE {

	@Autowired
	private IDetallePagoDAO pDAO;

	@Override
	public void insertar(DetallePago detallepago) {
		pDAO.save(detallepago);

	}

	@Override
	public void modificar(DetallePago detallepago) {
		pDAO.save(detallepago);

	}

	@Override
	public void eliminar(int idDetallePago) {
		pDAO.delete(idDetallePago);

	}

	@Override
	public DetallePago listarId(int idDetallePago) {
		return pDAO.findOne(idDetallePago);
	}

	@Override
	public List<DetallePago> listar() {
		return pDAO.findAll();
	}

	@Override
	public List<DetallePago> findBydescripcion(String descripcion) {
		return pDAO.findBydescripcion(descripcion);
	}

	@Override
	public List<DetallePago> findBynombreCliente(String nombreCliente) {
		return pDAO.findBynombreCliente(nombreCliente);
	}

}
