package pe.edu.upc.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entity.Cliente;
import pe.edu.upc.service.IClienteSERVICE;

@Controller
@RequestMapping("/cliente")
public class ClienteController {

	@Autowired
	private IClienteSERVICE clienteService;

	@RequestMapping("/")
	public String irCliente(Map<String, Object> model) {
		model.put("listaClientes", clienteService.listar());
		return "listCliente";
	}

	@RequestMapping("/irRegistrar")
	public String irRegistrar(Model model) {
		model.addAttribute("cliente", new Cliente());
		return "cliente";
	}

	@RequestMapping("/registrar")
	public String registrar(Map<String, Object> model, @ModelAttribute @Valid Cliente cliente, BindingResult binRes)
			throws ParseException {
		if (binRes.hasErrors()) {
			return "cliente";
		} else {
			if (cliente.getIdCliente() > 0) {
				clienteService.modificar(cliente);
			} else {
				clienteService.insertar(cliente);
			}
			model.put("listaClientes", clienteService.listar());
			model.put("Mensaje", "Error!!");
			return "listCliente";
		}
	}

	@RequestMapping("/modificar")
	public String modificar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		Cliente cli = clienteService.listarId(id);
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		cli.setFechaString(sdf.format(cli.getBirthDateCliente()));
		model.put("cliente", cli);
		return "cliente";
	}

	@RequestMapping("/eliminar")
	public String eliminar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				clienteService.eliminar(id);
				model.put("listaClientes", clienteService.listar());
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "listCliente";
	}

	@RequestMapping("/listar")
	public String listar(Map<String, Object> model) {

		model.put("listaClientes", clienteService.listar());
		return "listCliente";
	}

	@RequestMapping("/listarId")
	public String listarId(Map<String, Object> model, @ModelAttribute Cliente cliente) {
		clienteService.listarId(cliente.getIdCliente());
		return "listCliente";
	}

	@RequestMapping("/buscar")
	public String buscar(Map<String, Object> model, @ModelAttribute Cliente cliente) throws ParseException {
		List<Cliente> listaClientes;
		if (StringUtils.isNumeric(cliente.getDniCliente())) {

			listaClientes = clienteService.findByDniCliente(cliente.getDniCliente());

		} else {
			cliente.setNombreCliente(cliente.getDniCliente());
			listaClientes = clienteService.buscarNombre(cliente.getNombreCliente());

		}

		if (listaClientes.isEmpty()) {

			model.put("mensaje", "No se encontró");
		}
		model.put("listaClientes", listaClientes);
		return "buscarCliente";
	}

	@RequestMapping("/irBuscar")
	public String irBuscar(Model model) {
		model.addAttribute("cliente", new Cliente());
		return "buscarCliente";
	}

}
