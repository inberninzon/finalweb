package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entity.Membresia;

public interface IMembresiaSERVICE {

	void insertar(Membresia membresia);

	void modificar(Membresia membresia);

	void eliminar(int idMembresia);

	Membresia listarId(int idMembresia);

	List<Membresia> listar();
}
