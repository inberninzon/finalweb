package pe.edu.upc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "nivel")
public class Nivel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idNivel;

	@NotEmpty(message = "No puede estar vacío")
	@NotBlank(message = "No puede estar en blanco")
	@Column(name = "tNivel", length = 60, nullable = false)
	private String tNivel;

	public Nivel() {
		super();
	}

	public Nivel(int idNivel, String tNivel) {
		super();
		this.idNivel = idNivel;
		this.tNivel = tNivel;
	}

	public int getIdNivel() {
		return idNivel;
	}

	public void setIdNivel(int idNivel) {
		this.idNivel = idNivel;
	}

	public String gettNivel() {
		return tNivel;
	}

	public void settNivel(String tNivel) {
		this.tNivel = tNivel;
	}

}
