package pe.edu.upc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.dao.IAsistenciaDAO;
import pe.edu.upc.entity.Asistencia;

@Service
public class AsistenciaSERVICEImpl implements IAsistenciaSERVICE {

	@Autowired
	private IAsistenciaDAO aDAO;

	@Override
	public void insertar(Asistencia asistencia) {
		aDAO.save(asistencia);

	}

	@Override
	public void modificar(Asistencia asistencia) {
		aDAO.save(asistencia);

	}

	@Override
	public void eliminar(int idAsistencia) {
		aDAO.delete(idAsistencia);

	}

	@Override
	public Asistencia listarId(int idAsistencia) {
		return aDAO.findOne(idAsistencia);
	}

	@Override
	public List<Asistencia> listar() {
		return aDAO.findAll();
	}

	@Override
	public List<Asistencia> findBynombreCliente(String nombreCliente) {
		return aDAO.findBynombreCliente(nombreCliente);
	}

	@Override
	public List<Asistencia> findBydniCliente(String dniCliente) {
		return aDAO.findBydniCliente(dniCliente);
	}

}
