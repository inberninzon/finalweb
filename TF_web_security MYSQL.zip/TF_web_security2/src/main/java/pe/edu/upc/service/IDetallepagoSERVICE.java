package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entity.Detallepago;

public interface IDetallepagoSERVICE {
	void insertar(Detallepago detallepago);

	void modificar(Detallepago detallepago);

	void eliminar(int idDetallepago);

	Detallepago listarId(int idDetallepago);

	List<Detallepago> listar();

	List<Detallepago> findBydniCliente(String dniCliente);

	List<Detallepago> findBynombreMembresia(String nombreMembresia);
}
