package pe.edu.upc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.dao.IClienteDAO;
import pe.edu.upc.entity.Cliente;

@Service
public class ClienteSERVICEImpl implements IClienteSERVICE {

	@Autowired
	private IClienteDAO cDAO;

	@Override
	public void insertar(Cliente cliente) {
		cDAO.save(cliente);
	}

	@Override
	public void modificar(Cliente cliente) {
		cDAO.save(cliente);
	}

	@Override
	public void eliminar(int idCliente) {
		cDAO.delete(idCliente);

	}

	@Override
	public Cliente listarId(Integer idCliente) {
		return cDAO.findOne(idCliente);
	}

	@Override
	public List<Cliente> listar() {
		return cDAO.findAll();
	}

	@Override
	public List<Cliente> findByDniCliente(String dni) {
		return cDAO.findByDniCliente(dni);
	}

	@Override
	public List<Cliente> buscarNombre(String name) {
		return cDAO.buscarNombre(name);
	}

}
