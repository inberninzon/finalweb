package pe.edu.upc.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "asistencia")
public class Asistencia implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idAsistencia;

	@NotNull
	@Temporal(TemporalType.TIME)
	@Column(name = "horaInicio")
	@DateTimeFormat(pattern = "kk:mm")
	private Date horaInicio;

	@NotNull
	@Temporal(TemporalType.TIME)
	@Column(name = "horaFin")
	@DateTimeFormat(pattern = "kk:mm")
	private Date horaFin;

	@NotNull
	@Past(message = "La fecha debe estar en el pasado")
	@Temporal(TemporalType.DATE)
	@Column(name = "fechaClase")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fechaClase;

	private String fechaString;
	private String horaInicioString;
	private String horaFinString;

	@ManyToOne
	@JoinColumn(name = "idCliente", nullable = false)
	private Cliente cliente;

	@ManyToOne
	@JoinColumn(name = "idNivel", nullable = false)
	private Nivel nivel;

	public Asistencia() {
		super();
	}

	public Asistencia(int idAsistencia, Date horaInicio, Date horaFin, Date fechaClase, String fechaString,
			String horaInicioString, String horaFinString, Cliente cliente, Nivel nivel) {
		super();
		this.idAsistencia = idAsistencia;
		this.horaInicio = horaInicio;
		this.horaFin = horaFin;
		this.fechaClase = fechaClase;
		this.fechaString = fechaString;
		this.horaInicioString = horaInicioString;
		this.horaFinString = horaFinString;
		this.cliente = cliente;
		this.nivel = nivel;
	}

	public Date getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(Date horaInicio) {
		this.horaInicio = horaInicio;
	}

	public Date getHoraFin() {
		return horaFin;
	}

	public void setHoraFin(Date horaFin) {
		this.horaFin = horaFin;
	}

	public String getHoraInicioString() {
		return horaInicioString;
	}

	public void setHoraInicioString(String horaInicioString) {
		this.horaInicioString = horaInicioString;
	}

	public String getHoraFinString() {
		return horaFinString;
	}

	public void setHoraFinString(String horaFinString) {
		this.horaFinString = horaFinString;
	}

	public int getIdAsistencia() {
		return idAsistencia;
	}

	public void setIdAsistencia(int idAsistencia) {
		this.idAsistencia = idAsistencia;
	}

	public Date getFechaClase() {
		return fechaClase;
	}

	public void setFechaClase(Date fechaClase) {
		this.fechaClase = fechaClase;
	}

	public String getFechaString() {
		return fechaString;
	}

	public void setFechaString(String fechaString) {
		this.fechaString = fechaString;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Nivel getNivel() {
		return nivel;
	}

	public void setNivel(Nivel nivel) {
		this.nivel = nivel;
	}

}
