package pe.edu.upc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.dao.IMembresiaDAO;
import pe.edu.upc.entity.Membresia;

@Service
public class MembresiaSERVICEImpl implements IMembresiaSERVICE {

	@Autowired
	private IMembresiaDAO mDAO;

	@Override
	public void insertar(Membresia membresia) {
		mDAO.save(membresia);

	}

	@Override
	public void modificar(Membresia membresia) {
		mDAO.save(membresia);
	}

	@Override
	public void eliminar(int idMembresia) {
		mDAO.delete(idMembresia);

	}

	@Override
	public Membresia listarId(int idMembresia) {
		return mDAO.findOne(idMembresia);
	}

	@Override
	public List<Membresia> listar() {
		return mDAO.findAll();
	}

}
