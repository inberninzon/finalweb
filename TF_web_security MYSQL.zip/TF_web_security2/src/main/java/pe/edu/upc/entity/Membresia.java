package pe.edu.upc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "membresia")
public class Membresia implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idMembresia;

	@NotEmpty(message = "No puede estar vacío")
	@NotBlank(message = "No puede estar en blanco")
	@Column(name = "nombreMembresia", length = 60, nullable = false)
	private String nombreMembresia;

	@Range(min = 0, max = 99999999, message = "Debe ser numero")
	@Column(name = "monto", length = 8, nullable = false)
	private String monto;

	public Membresia() {
		super();
	}

	public Membresia(int idMembresia, String nombreMembresia, String monto) {
		super();
		this.idMembresia = idMembresia;
		this.nombreMembresia = nombreMembresia;
		this.monto = monto;
	}

	public int getIdMembresia() {
		return idMembresia;
	}

	public void setIdMembresia(int idMembresia) {
		this.idMembresia = idMembresia;
	}

	public String getNombreMembresia() {
		return nombreMembresia;
	}

	public void setNombreMembresia(String nombreMembresia) {
		this.nombreMembresia = nombreMembresia;
	}

	public String getMonto() {
		return monto;
	}

	public void setMonto(String monto) {
		this.monto = monto;
	}

}
