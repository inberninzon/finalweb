package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entity.Asistencia;

public interface IAsistenciaSERVICE {

	void insertar(Asistencia asistencia);

	void modificar(Asistencia asistencia);

	void eliminar(int idAsistencia);

	Asistencia listarId(int idAsistencia);

	List<Asistencia> listar();

	List<Asistencia> findBydniCliente(String dniCliente);

	List<Asistencia> findBynombreCliente(String nombreCliente);
}
