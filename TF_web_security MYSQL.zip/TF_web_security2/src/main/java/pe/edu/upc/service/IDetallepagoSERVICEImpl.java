package pe.edu.upc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.dao.IDetallepagoDAO;
import pe.edu.upc.entity.Detallepago;

@Service
public class IDetallepagoSERVICEImpl implements IDetallepagoSERVICE {

	@Autowired
	private IDetallepagoDAO dDAO;

	@Override
	public void insertar(Detallepago detallepago) {
		dDAO.save(detallepago);

	}

	@Override
	public void modificar(Detallepago detallepago) {
		dDAO.save(detallepago);

	}

	@Override
	public void eliminar(int idDetallepago) {
		dDAO.delete(idDetallepago);

	}

	@Override
	public Detallepago listarId(int idDetallepago) {
		return dDAO.findOne(idDetallepago);
	}

	@Override
	public List<Detallepago> listar() {
		return dDAO.findAll();
	}

	@Override
	public List<Detallepago> findBydniCliente(String dniCliente) {
		return dDAO.findBydniCliente(dniCliente);
	}

	@Override
	public List<Detallepago> findBynombreMembresia(String nombreMembresia) {
		return dDAO.findBynombreMembresia(nombreMembresia);
	}
}
