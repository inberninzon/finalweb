package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entity.Nivel;

public interface INivelSERVICE {
	void insertar(Nivel nivel);

	void modificar(Nivel nivel);

	void eliminar(int idNivel);

	Nivel listarId(int idNivel);

	List<Nivel> listar();
}
