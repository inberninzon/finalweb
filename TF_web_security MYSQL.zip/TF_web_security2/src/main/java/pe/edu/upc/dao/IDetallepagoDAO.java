package pe.edu.upc.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.upc.entity.Detallepago;

@Repository
public interface IDetallepagoDAO extends JpaRepository<Detallepago, Integer> {

	@Query("from detallepago d where d.cliente.dniCliente like %:dniCliente%")
	List<Detallepago> findBydniCliente(@Param("dniCliente") String dniCliente);

	@Query("from detallepago d where d.membresia.nombreMembresia like %:nombreMembresia%")
	List<Detallepago> findBynombreMembresia(@Param("nombreMembresia") String nombreMembresia);
}
